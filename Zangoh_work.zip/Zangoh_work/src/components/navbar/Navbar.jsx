
function Navbar() {
  return (
    <div className="md:flex justify-between mx-20 mt-10 h-8 items-center">
       <div className="flex gap-2 h-20">
           <img src="/Images\Vector.png"></img>
           <h1 className="text-[#3BAA14] font-bold text-6xl">Green</h1>
       </div>
       <div className="md:visible hidden">
           <ul className="md:flex items-center gap-4">
             <li>About Us</li>
             <li>Shop</li>
             <li>Cart</li>
             <li>Offers</li>
             <li>
                <img src="/Images\Frame 43.png"></img>
             </li>
           </ul>
       </div>
       <div className="flex gap-4 items-center md:visible hidden">
           <div className="">
            <img src="\Images\streamline_web.png"></img>
           </div>
           <div className="flex gap-1">
             <img src="\Images\Group.png"></img>
             <p>My Account</p>
           </div>
       </div>
    </div>
  )
}

export default Navbar