import { useState } from "react"

function Bottom() {
    const [isClicked,setIsClicked]=useState(false);
    const check=()=>{
           setIsClicked(!isClicked);
    }
  return (
    <div className='lg:flex justify-between mx-20 lg:mt-60 mt-10 h-8 items-center'>
        <div className="md:flex flex-col gap-40">
            <div>
            <p>Lorem ipsum dolor sit amet consectetur. </p>
            <p> Mattis accumsan parturient pretium turpis.</p>
            </div>
            <div>
            <button className="bg-[#8beb68] rounded-lg flex gap-2 p-1 mt-2">Go Green <img src='\Images\north_east.png' className="bg-[#3BAA14] border-none rounded-md rounded-3xl p-1" ></img></button>
            </div>
        </div>
        <div>
            <img src='\Images\unsplash_W1yjvf5idqA (1) 1.png' ></img>
        </div>
        <div className="md:flex flex-col gap-40 items-end">
            <div>
            <p>Lorem ipsum dolor sit amet consectetur. </p>
            <p> Mattis accumsan parturient pretium turpis.</p>
            </div>
            <div >
                <img src="/Images/_.png" className="bg-[#3BAA14] rounded-3xl p-1 md:visible hidden"
                onClick={check}
                ></img>
            </div>
            </div>
        </div>
  )
}

export default Bottom