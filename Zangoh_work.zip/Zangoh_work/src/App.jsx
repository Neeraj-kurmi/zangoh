
import Bottom from './components/Bottom'
import Navbar from './components/navbar/Navbar'

function App() {

  return (
    <>
       <Navbar/>
       <div className='md:flex gap-4 justify-between md:mx-20 md:mt-20 mt-20 mx-16'>
         <h1 className='text-[#3BAA14] lg:text-8xl text-6xl'>Greenwave </h1>
         <h1 className='text-[#3BAA14] lg:text-8xl text-6xl'>Ecology </h1>
       </div>
       <Bottom/>
    </>
  )
}

export default App
